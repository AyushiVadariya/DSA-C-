 #include <iostream>
using namespace std;
struct node
{
    public:
 int data;
 node *left;
 node *right;
  void insert(node *root, node *New)
 {
 cout<<"Where to insert left/right of"<<root->data;
 char ch;
 cin>>ch;
 if(ch=='r')
 {
 if(root->right== NULL)
 root->right=New;
 else
 insert(root->right,New);
 }
 else
 {
 if(root->left== NULL)
 root->left=New;
 else
 insert(root->left,New);
 }
 }
 void preorder(node *root)
    {
        if (root == NULL)
            return;
        // cout << root->data;
        preorder(root->left);
        // cout << root->data;
        preorder(root->right);
        cout << root->data;
    }
};
node* get_node()
    {
    node *temp;
    temp=new node;
    temp->left=NULL;
    temp->right=NULL;
    return temp;
    }
 int main()
 {
 node *New,*root;
 root=NULL;
 char ans;
 do
 {
 New=get_node();
 cin>>New->data;
 if(root==NULL)
 {
    root=New;
 }
 else
 {
    root->insert(root,New);
 }
 cout<<"do you want to enter more elements?"<<endl;
 cin>>ans;
 }while(ans=='y');
  root->preorder(root);
 }