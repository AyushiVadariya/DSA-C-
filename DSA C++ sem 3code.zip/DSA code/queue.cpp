#include<iostream>
using namespace std;
const int size=5;
class queue
{
    int front;
    int rear;
    int q[size];
    public:
    queue()
    {
        front=-1;
        rear=-1;
    }
    void Enqueue(int n)
    {
        if(rear>=size-1)
        {
            cout<<"queue is full";
            return;
        }
        else if(front==-1)
        {
            front++;
        }
        q[++rear]=n;
    } 
    int dequeue()
    {
        if(front==-1 || front>rear)
        {   
            cout<<"queue is empty ";
            return -1;
        }
        else{
            int n=q[front++];
            return n;
        }
    }
    void display() {
        if (front == -1 || front > rear) {
            cout << "Queue is empty!" << endl;
            return;
        }
        
        cout << "Queue elements: ";
        for (int i = front; i <= rear; i++) {
            cout << q[i] << " ";
        }
        cout << endl;
    }
};
int main()
{
    queue q1;
    int a;
    cout<<"enetr value";
    for(int i=0;i<size;i++)
    {
        cin>>a;
        q1.Enqueue(a);
    }
    q1.display();
}