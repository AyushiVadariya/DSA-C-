#include<iostream>
using namespace std;
class queue
{
    public:
    int data;
    queue *link;

    queue(int d)
    {
        data=d;
        link='\0';
    }
};
class implementation
{
    queue *front;
    queue *rear;
    public:

    implementation()
    {
        front='\0';
        rear='\0';
    }
    void insert(int d)
    {
        queue *nn=new queue(d);
        if(rear==nullptr)
        {
             front=rear=nn;
        }
        else{
            rear->link=nn;
            rear=rear->link;

        }
       
    }
    void remove()
    {
        if(front==nullptr)
        {
            cout<<"queue is empty";
        }
        else{
            int x=front->data;
            cout<<x;
            front=front->link;
        }
    }
};
int main()
{
    implementation i1;
    for(int i=0;i<4;i++)
    {
         i1.insert(i+1);
    }
    for(int i=0;i<5;i++)
    {
         i1.remove();
    }
}