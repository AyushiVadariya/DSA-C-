#include<iostream>
#include<stack>
using namespace std;

class demo {
    stack<int> st;  // Stack to hold the digits temporarily
    string s1;

public:
    demo(string str) {
        s1 = str;
    }

    void sort() {
        // Sorting the digits using the stack
        for (int i = 0; i < s1.length(); i++) {
            // Convert character to integer (to sort by numeric value)
            int x = s1[i] - '0'; // Convert char to int

            // Pop elements from stack until we find the correct position for x
            while (!st.empty() && st.top() > x) {
                // Pop the top element of the stack and push it back later
                int n = st.top();
                st.pop();
                st.push(n);
            }

            // Now push the current element into the stack
            st.push(x);
        }

        // Display the stack after sorting
        display();
    }

    void display() {
        // Display the stack content in reverse order
        // Because we need to print the elements in ascending order
        stack<int> reverseStack;
        while (!st.empty()) {
            reverseStack.push(st.top());
            st.pop();
        }

        while (!reverseStack.empty()) {
            cout << reverseStack.top();  // Output the top element of the stack
            reverseStack.pop();  // Pop the top element from the stack
        }
        cout << endl;
    }
};

int main() {
    string s = "3549821";  // Sample input string
    demo d(s);
    d.sort();  // Call the sort method
    return 0;
}