#include <iostream>
using namespace std;
struct node
{
public:
    int data;
    struct node *link;

    node(int d, node *head)
    {
        data = d;
        link = head;
    }
};
class implementation
{
    node *first;

public:
    implementation()
    {
        first = '\0';
    }
    void insertend(int d)
    {
        if (first == nullptr)
        {
            first = new node(d, first);
            first->link = first;
        }
        else
        {
            node *temp = first;
            while (temp->link != first)
            {
                temp = temp->link;
            }
            node *nn = new node(d, first);
            temp->link = nn;
        }
    }
    void display()
    {
        node *temp = first;
        while (temp->link != first)
        {
            cout << temp->data << endl;
            temp = temp->link; // cout<<temp->data<<endl;
        }
        cout << temp->data << endl;
    }
};
int main()
{
    implementation obj1;
    obj1.insertend(10);
    obj1.insertend(20);
    obj1.insertend(30);
    obj1.insertend(40);
    obj1.insertend(50);
    obj1.display();
}