#include<iostream>
using namespace std;

class pol
{
    int coff;
    int expo;
    public:

    void input()
    {
        cin>>coff;
        cin>>expo;
    }

    int add(pol p1[],pol p2[],pol p3[],int t1,int t2)
    {
        int i=0,j,k=0,next3,flag;
        int ex,co;
        i=next3=0;

        while(i<t1)
        {
            j=0;
            while(j<t2)
            {
                ex=p1[i].expo+p2[j].expo;
                co=p1[i].coff*p2[j].coff;
                k=flag=0;
                while(k<next3 && !flag)
                {
                    if(p3[k].expo==ex)
                    {
                        flag=1;
                        break;
                    }
                    else{
                        k++;
                    }
                }
                  if(flag==1)
                    {
                        p3[k].coff=p3[k].coff+co;
                    }
                    else{
                        p3[next3].expo=ex;
                        p3[next3].coff=co;
                        next3++;
                    }
                    j++;
            }
            i++;
        }
        return next3;
    }
    void display()
    {
        cout<<coff<<",";
        cout<<expo<<endl;
    }

};
int main()
{
    pol p1[5];
    pol p2[5];
    int i;

    cout<<"enter first polynomial"<<endl;
    for(i=0;i<4;i++)
    {
        p1[i].input();
    }
    cout<<"enter second polynomial"<<endl;
    for(i=0;i<2;i++)
    {
        p2[i].input();
    }
    int a;
    pol p3[10];
    pol p4;
    a=p4.add(p1,p2,p3,4,2);
    cout<<"display";
    for(i=0;i<a;i++)
    {
        p3[i].display();
    }
}