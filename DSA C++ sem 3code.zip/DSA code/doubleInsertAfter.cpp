#include<iostream>
using namespace std;
class dnode
{
    public:

    int data;
    dnode *next;
    dnode *prev;

    dnode(int d)
    {
        data=d;
        next=nullptr;
        prev=nullptr;
    }
};
class implementation
{
    dnode *first;
    public:

    implementation()
    {
        first=nullptr;
    }
    void insertend(int d)
    {
        dnode *nn=new dnode(d);
        {
            if(first==nullptr)
            {
                first=nn;
            }
            else{
                dnode *temp=first;
                while(temp->next!=nullptr)
                {
                    temp=temp->next;
                }
                temp->next=nn;
                temp->prev=temp;
            }
        }
    }
    void insertafter(int x,int y)
    {
        dnode *temp=first;
        dnode *nn=new dnode(y);
        while(temp->data!=x)
        {
            temp=temp->next;
        }
        nn->next=temp->next;
        nn->prev=temp;
       
        temp->next->prev=nn;
         temp->next=nn;
    }
    void display()
    {
        dnode *temp=first;
        while(temp!=nullptr)
        {
            cout<<temp->data<<endl;
            temp=temp->next;
             //cout<<temp->data<<endl;
        }
    }
};
int main()
{
    implementation obj1;
    obj1.insertend(10);
    obj1.insertend(20);
    obj1.insertend(30);
    obj1.insertend(40);
    obj1.insertafter(20,50);
    obj1.display();
}