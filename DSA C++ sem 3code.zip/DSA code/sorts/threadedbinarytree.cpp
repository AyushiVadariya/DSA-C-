#include<iostream>
using namespace std;

class node
{
    public:
    int data;
    node* left;
    node*right;
    bool rightthread;
    bool leftthread;

};

node* addnode()
{
    node *temp;
    temp=new node();
    temp->right=NULL;
    temp->left=NULL;
    temp->rightthread=true;
    temp->leftthread=true;
    return temp;
}

void insert(node *root, node *New) {
    if (New->data > root->data) {
        if (root->right == NULL || root->rightthread) {
            New->right = root->right;
            New->left = root;
            root->right = New;
            root->rightthread = false;
        } else {
            insert(root->right, New);
        }
    } else {
        if (root->left == NULL || root->leftthread) {
            New->left = root->left;
            New->right = root;
            root->left = New;
            root->leftthread = false;
        } else {
            insert(root->left, New);
        }
    }
}
node* leftmost(node* root) 
{
    
    if (root == NULL) 
        return NULL;
    while (root->left != NULL && !root->leftthread) 
        root = root->left;
    return root;
}

void inorder_traversal(node* root) {
   
    node* current = leftmost(root);
    
    while (current != NULL) {
        // Visit the node
        cout << current->data << " ";
        
        // If right-thread is true, move to the in-order successor
        if (current->rightthread) {
            current = current->right;
        } 
        // Otherwise, move to the leftmost node in the right subtree
        else {
            current = leftmost(current->right);
        }
    }
}



int main()
{
    node *root=NULL;
    node *New;
    char ans;
    do
    {
        New=addnode();
        cout<<"enter data";
        cin>>New->data;
        if(root==NULL)
        root=New;
        else
        insert(root,New);
        cout<<"want add  more";
        cin>>ans;
    }while(ans=='y');

cout << "In-order traversal: ";
    inorder_traversal(root);
    cout << endl;
return 0; 
}
