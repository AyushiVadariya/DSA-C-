#include <iostream>
using namespace std;

class tree;

class node {
    int data;
    node *left;
    node *right;

public:
    node(int d) {
        data = d;
        left = right = nullptr;
    }
    friend class tree;
};

class tree {
public:
    node *root;
    
    tree() {
        root = nullptr;
    }

    // Function to insert a node into the tree recursively
    void insert(node *root, node *n) {
        char ch;
        cout << "Enter choice for " << n->data << " (l for left, r for right): ";
        cin >> ch;
        if (ch == 'r') {
            if (root->right == nullptr) {
                root->right = n;
            } else {
                cout << "Right child of node " << root->data << " is not null. Enter choice for this node again." << endl;
                insert(root->right, n);
            }
        } else if (ch == 'l') {
            if (root->left == nullptr) {
                root->left = n;
            } else {
                cout << "Left child of node " << root->data << " is not null. Enter choice for this node again." << endl;
                insert(root->left, n);
            }
        } else {
            cout << "Invalid input. Please enter 'l' or 'r'." << endl;
            insert(root, n);
        }
    }

    // Function to print the tree using in-order traversal
    void print(node *root) {
        if (root == nullptr) return;
        if(!root->left && !root->right)
        {
            cout << root->data << " ";
            return;
        }
        if(root->left)
        {
            print(root->left);
        }
       if(root->right)
        {
            print(root->right);
        }
    }

    // Function to add a node to the tree
    void addnode(int d) {
        node *nn = new node(d);
        if (root == nullptr) {
            root = nn;
        } else {
            insert(root, nn);
        }
    }

    // Function to display the tree
    void display() {
        print(root);
    }
};

int main() {
    tree t1;
    t1.addnode(5);  // Root node
    t1.addnode(3);  // Insert a left or right child
    t1.addnode(10);  // Insert another left or right child
    t1.addnode(15);  // Continue inserting nodes
    t1.addnode(9);
    t1.addnode(23);
    t1.addnode(7);
    t1.addnode(13);
    cout << "In-order traversal of the tree: ";
    t1.display();  // Display the tree in in-order
    cout << endl;

    return 0;
}