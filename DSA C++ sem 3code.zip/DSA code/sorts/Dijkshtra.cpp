#include <iostream>
using namespace std;

class Graph_path
{
    int g[10][10];
    int n;

    public:

    void WeightedGraph(int a)
    {
        n=a;
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)
            {
                cout<<"Enter cost of "<<i<<" to "<<j<<": ";
                cin>>g[i][j];
            }
       }
    }

    void Diksatra()
    {
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)
            {
                for(int k=0;k<n;k++)
                {
                    if(g[j][i]+g[i][k] < g[j][k])
                        g[j][k] = g[j][i]+g[i][k];
                }
            }
            show();
        }
    }

    void show()
    {
        cout<<endl;
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)
            {
                cout<<g[i][j]<<"\t";
            }
            cout<<endl;
        }
    }
};

int main()
{
    Graph_path g;
    g.WeightedGraph(3);
    g.show();
    g.Diksatra();
    return 0;
}
class Solution {
public:
    vector<vector<int>> merge(vector<vector<int>>& intervals) {
        int n=intervals.size();
        vector<int> level;
        vector<vector<int>> result;
        sort(intervals.begin(), intervals.end());
        level = intervals[0];
        for(int i=1;i<n;i++)
        {
                if(level[1]>=intervals[i][0])
                {
                    level[1]=max(level[1],intervals[i][1]);
                }
                else
                {
                    result.push_back(level); 
                    level=intervals[i];
                } 
        }
        result.push_back(level);
        return result;
    }
};