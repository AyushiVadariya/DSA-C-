#include<iostream>
using namespace std;

void simplemergesort(int a[], int l, int m, int n) {
    int result[n - l + 1];
    int i = l;
    int j = m + 1;
    int k = 0;

    // Merge two subarrays into the result array
    while (i <= m && j <= n) {
        if (a[i] < a[j]) {
            result[k] = a[i];
            i++;
        } else {
            result[k] = a[j];
            j++;
        }
        k++;
    }

    // Copy any remaining elements from the left subarray
    while (i <= m) {
        result[k] = a[i];
        i++;
        k++;
    }

    // Copy any remaining elements from the right subarray
    while (j <= n) {
        result[k] = a[j];
        j++;
        k++;
    }

    // Copy the merged elements back into the original array
    for (int i = l, k = 0; i <= n; i++, k++) {
        a[i] = result[k];
    }
}

void rmerge(int a[], int L, int H) {
    if (L < H) {
        int M = (L + H) / 2;
        rmerge(a, L, M);        // Sort the first half
        rmerge(a, M + 1, H);    // Sort the second half
        simplemergesort(a, L, M, H); // Merge the two halves
    }
}

int main() {
    int size = 10; 
    int a[size];

    cout << "Enter 10 elements: ";
    for (int i = 0; i < size; i++) {
        cin >> a[i];
    }

    rmerge(a, 0, size - 1);

    cout << "Sorted array: ";
    for (int i = 0; i < size; i++) {
        cout << a[i] << " ";
    }
    cout << endl;

    return 0;
}