#include<iostream>
using namespace std;
int quicksort(int a[],int low,int high)
{
    if(low<high)
    {
        int pivot=a[low];
        int i=low;
        int j=high+1;
    do
    {
        do
        {
            i++;
        } while(pivot>a[i]);
        do
        {
            j--;
        }while(pivot<a[j]);
        if(i<j)
        {
            swap(a[i],a[j]);
        }
    }
    while(i<j);
    if(i>j)
    {
         swap(a[low],a[j]);
    }
    quicksort(a,low,j-1);
    quicksort(a,j+1,high);
    }
}
int main()
{
    int n,i;
    cout<<"enter the size of array";
    cin>>n;
    int a[n];
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
    }
    quicksort(a,0,n-1);
    for(int i=0;i<n;i++)
    {
        cout<<a[i]<<"\t";
    }
}




?


class Solution {
    public int minimumOperations(int[] nums) {
        int count=0;
        int pos=3;
        int n=nums.length;
        for(int i=0;i<n;i++)
        {
            for(int j=i+1;j<n;j++)
            {
                if(nums[i]==nums[j])
                {
                    count++;
                    deleteele(nums);
                }
            }
        }
        return count;
    }
    public  int[] deleteele(int[] nums)
    {
         int n=nums.length;
        for(int k=0;k<n-3;k++)
            {
                nums[k]=nums[k+3];   
            }
        return nums;
    }
}