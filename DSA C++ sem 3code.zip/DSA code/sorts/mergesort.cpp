#include<iostream>
using namespace std;
int simplemergesort(int a[],int l,int m,int n)
{
    int result[n-l+1];
    int i=l;
    int j=m+1;
    int k=0;
    while(i<=m && j<=n)
    {
        if(a[i]<a[j])
        {
            result[k]=a[i];
            i++;
            k++;
        }
        else{
            result[k]=a[j];
            j++;
            k++;
        }
    }
    while(i<=m)
    {
        result[k]=a[i];
        i++;
        k++;
    }
    while(j<=n)
    {
        result[k]=a[j];
        j++;
        k++;
    }
    for(int i=0;i<n;i++)
    {
        cout<<result[i]<<"\t";
    }
}
int main()
{
    int size,i;
    int l,m,n;
    l=1;
    m=4;
    n=10;
    int a[n];
    for(int i=1;i<=n;i++)
    {
        cin>>a[i];
    }
    simplemergesort(a,l,m,n);

}
//10 20 30 40 15 18 25 35 60 70 80