#include<iostream>
using namespace std;
class stacknode
{
    public:
    int data;
    stacknode *link;

    stacknode(int d,stacknode *top)
    {
        data=d;
        link=top;
    }
};
class stack
{
    stacknode *top;
    public:
    stack()
    {
        top='\0';
    }
    
    void push(int d)
    {
        top=new stacknode(d,top);
    }

    int pop()
    {
        if(top=='\0')
        {
            cout<<"stack is empty";
        }
        else{
            int x=top->data;
            cout<<x<<endl;
            top=top->link;
        }
    }
};
int main()
{
    stack s1;
    s1.push(10);
    s1.push(20);
    s1.push(30);
    s1.push(40);
    s1.pop();
    s1.pop();
    s1.pop();
    s1.pop();
    s1.pop();
}