#include <iostream>
using namespace std;

class node
{
public:
    int data;
    node *link;

    node(int d)
    {
        data = d;
        link = nullptr; // Use nullptr instead of '\0'
    }
};

class implementation
{
    node *first;

public:
    implementation()
    {
        first = nullptr; // Use nullptr instead of '\0'
    }

    void insertSorted(int d)
    {
        node *nn = new node(d);
        if (first == nullptr || first->data >= d)
        {
            nn->link = first;
            first = nn;
        }
        else
        {
            node *temp = first;
            while (temp->link != nullptr && temp->link->data < d)
            {
                temp = temp->link;
            }
            nn->link = temp->link;
            temp->link = nn;
        }
    }

    void display()
    {
        node *temp = first;
        while (temp != nullptr)
        {
            cout << temp->data << " ";
            temp = temp->link;
        }
        cout << endl;
    }
};

int main()
{
    implementation obj;
    obj.insertSorted(30);
    obj.insertSorted(10);
    obj.insertSorted(20);
    obj.insertSorted(50);
    obj.insertSorted(40);
    obj.display();

    return 0;
}