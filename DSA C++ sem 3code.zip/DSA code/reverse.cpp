#include<iostream>
using namespace std;
class node
{
    public:

    int data;
    node *link;

    node(int d)
    {
        data=d;
        link='\0';
    }
};
class implementation
{
    node *first;
    public:

    implementation()
    {
        first='\0';
    }
    void insertend(int d)
    {
        node *nn=new node(d);
        {
            if(first=='\0')
            {
                first=nn;
            }
            else{
              node *temp=first;
                while(temp->link!='\0')
                {
                    temp=temp->link;
                }
                temp->link=nn;
            }
        }
    }
    void displayReverse(node *head) {
        if (head->link == nullptr){
            cout << head->data << endl;
                return;
        }
            
            else{
                 displayReverse(head->link);
                  cout << head->data << endl;
            }
       
    }

    void display() {
        displayReverse(first);
    }
};
int main()
{
    implementation obj1;
    obj1.insertend(141);
    obj1.insertend(302);
    obj1.insertend(164);
    obj1.insertend(530);
    obj1.insertend(474);
    obj1.display();
}