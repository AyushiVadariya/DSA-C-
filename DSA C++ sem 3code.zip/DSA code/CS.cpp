#include <iostream>
#include <cmath>

int main() {
    const double A = 1.0;      // Amplitude
    const double T = 2.0;      // Period
    const double dt = 0.01;    // Time step
    const double endTime = 1.0; // End time

    for (double t = 0; t <= endTime; t += dt) {
        double x = A * sin(2 * M_PI * T * t);
        std::cout << "t: " << t << " x: " << x << std::endl;
    }

    return 0;
}