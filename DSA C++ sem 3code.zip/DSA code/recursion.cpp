#include<iostream>
using namespace std;
class node
{
    public:

    int data;
    node *link;

    node(int d)
    {
        data=d;
        link='\0';
    }
};
class implementation
{
    node *first;
    public:

    implementation()
    {
        first='\0';
    }
    void insertend(int d)
    {
        node *nn=new node(d);
        {
            if(first=='\0')
            {
                first=nn;
            }
            else{
                node *temp=first;
                while(temp->link!='\0')
                {
                    temp=temp->link;
                }
                temp->link=nn;
            }
        }
    }
    void display()
    {
        node *temp=first;
        while(temp!='\0')
        {
            cout<<temp->data<<endl;
            temp=temp->link;
             //cout<<temp->data<<endl;
        }
    }
};
int main()
{
    implementation obj1;
    obj1.insertend(10);
    obj1.insertend(20);
    obj1.insertend(30);
    obj1.insertend(40);
    obj1.insertend(50);
    obj1.display();
}