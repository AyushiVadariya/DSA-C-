#include<iostream>
using namespace std;
class dnode
{
    public:

    int data;
    dnode *next;
    dnode *prev;

    dnode(int d)
    {
        data=d;
        next=nullptr;
        prev=nullptr;
    }
};
class implementation
{
    dnode *first;
    public:

    implementation()
    {
        first=nullptr;
    }
    void insertend(int d)
    {
        dnode *nn=new dnode(d);
        {
            if(first==nullptr)
            {
                first=nn;
            }
            else{
                dnode *temp=first;
                while(temp->next!=nullptr)
                {
                    temp=temp->next;
                }
                temp->next=nn;
                nn->prev=temp;
                
            }
        }
    }
    int sum()
    {
        dnode *temp=first;
        int sum=0;
        while(temp!=nullptr)
        {
             sum+=temp->data;
             temp=temp->next;
             //cout<<sum<<endl;
        }
        return sum;
    }
    void display()
    {
        dnode *temp=first;
        int sumfinal=sum();
        while(temp!=nullptr)
        {
            int x=temp->data+sumfinal;
            cout<<x<<endl;
            temp=temp->next;
             //cout<<temp->data<<endl;
        }
    }
};
int main()
{
    implementation obj1;
    int size;
    cin>>size;
    int a[size];
    for(int i=0;i<size;i++)
    {
        cin>>a[i];
        obj1.insertend(a[i]);
    }
    obj1.display();
}
