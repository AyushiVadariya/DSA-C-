#include<iostream>
using namespace std;
class dnode
{
    public:

    int data;
    dnode *next;
    dnode *prev;

    dnode(int d)
    {
        data=d;
        next=nullptr;
        prev=nullptr;
    }
};
class implementation
{
    dnode *first;
    public:

    implementation()
    {
        first=nullptr;
    }
    void insertend(int d)
    {
        dnode *nn=new dnode(d);
        {
            if(first==nullptr)
            {
                first=nn;
            }
            else{
                dnode *temp=first;
                while(temp->next!=nullptr)
                {
                    temp=temp->next;
                }
                temp->next=nn;
              nn->prev=temp;
            }
        }
    }
    void deleteafter1(int x)
    {
        dnode *temp=first;
        while(temp->data!=x)
        {
            temp=temp->next;
        }
         temp->next->next->prev=temp;
        temp->next=temp->next->next; 
    }
    void display()
    {
        dnode *temp=first;
        while(temp!=nullptr)
        {
            cout<<temp->data<<endl;
            temp=temp->next;
             //cout<<temp->data<<endl;
        }
    }
};
int main()
{
    implementation obj1;
    obj1.insertend(10);
    obj1.insertend(20);
    obj1.insertend(30);
    obj1.insertend(40);
    obj1.deleteafter1(20);
    obj1.display();
    
}