#include <iostream>
using namespace std;
class term
{
public:
    int coff;
    int expo;
    term *link;
    term(int c, int e)
    {
        coff = c;
        expo = e;
        link = NULL;
    }
};
class poly
{
    term *first;

public:
    poly()
    {
        first = NULL;
    }
    term *getfirst()
    {
        return first;
    }
    void insertend(int c, int e)
    {
        term *t = new term(c, e);
        {
            if (first == '\0')
            {
                first = t;
            }
            else
            {
                term *temp = first;
                while (temp->link != '\0')
                {
                    temp = temp->link;
                }
                temp->link = t;
            }
        }
    }
    void addition(term *second)
    {
        poly p3;
        term *firstp, *secondp;
        firstp = first;
        secondp = second;
        while (firstp != '\0' && secondp != '\0')
        {
            if (firstp->expo == secondp->expo)
            {
                p3.insertend((firstp->coff + secondp->coff), firstp->expo);
                firstp = firstp->link;
                secondp = secondp->link;
            }
            else if (firstp->expo > secondp->expo)
            {
                p3.insertend(firstp->coff, firstp->expo);
                firstp = firstp->link;
            }
            else
            {
                p3.insertend(secondp->coff, secondp->expo);
                secondp = secondp->link;
            }
        }
        while (firstp != NULL)
        {
            p3.insertend(firstp->coff, firstp->expo);
            firstp = firstp->link;
        }
        while (secondp != NULL)
        {
            p3.insertend(secondp->coff, secondp->expo);
            secondp = secondp->link;
        }
        p3.display();
    }
    void display()
    {
        term *temp = first;
        while (temp != '\0')
        {
            cout << temp->coff << endl;
            cout << temp->expo << endl;
            temp = temp->link;
        }
    }
};

int main()
{
    poly p1;
    p1.insertend(3, 3);
    p1.insertend(2, 2);
    p1.insertend(1, 0);
    poly p2;
    p2.insertend(3, 2);
    p2.insertend(1, 0);
    p1.addition(p2.getfirst());
}