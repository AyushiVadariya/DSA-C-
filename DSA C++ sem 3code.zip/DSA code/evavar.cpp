#include <bits/stdc++.h>
using namespace std;

bool isop(char c)
{
    return (c == '+' || c == '-' || c == '*' || c == '/' || c == '%');
}

int fun(char c)
{
    if (c == '/' || c == '*' || c == '%')
        return 3;
    else if (c == '+' || c == '-')
        return 2;
    else
        return 1;
}

string postfix(stack<char> st, string s, string ans, int n)
{
    for (int i = 0; i < n; i++)
    {
        if (s[i] == '(')
        {
            st.push(s[i]);
        }
        else if (s[i] == ')')
        {
            while (!st.empty() && st.top() != '(')
            {
                ans += st.top();
                st.pop();
            }
            if (!st.empty())
                st.pop(); // Remove '('
        }
        else if (isop(s[i]))
        {
            while (!st.empty() && fun(s[i]) <= fun(st.top()))
            {
                ans += st.top();
                st.pop();
            }
            st.push(s[i]);
        }
        else
        {
            ans += s[i];
        }
    }
    while (!st.empty())
    {
        ans += st.top();
        st.pop();
    }
    return ans;
}

string prefix(stack<char> st, string ans1, string s)
{
    for (int i = 0; i < s.length(); i++)
    {
        if (isop(s[i]))
        {
            while (!st.empty() && fun(st.top()) >= fun(s[i]))
            {
                ans1 += st.top();
                st.pop();
            }
            st.push(s[i]);
        }
        else if (s[i] == ')')
        {
            st.push(s[i]);
        }
        else if (s[i] == '(')
        {
            while (!st.empty() && st.top() != ')')
            {
                ans1 += st.top();
                st.pop();
            }
            if (!st.empty())
                st.pop(); // Remove ')'
        }
        else
        {
            ans1 += s[i];
        }
    }
    while (!st.empty())
    {
        ans1 += st.top();
        st.pop();
    }
    reverse(ans1.begin(), ans1.end()); // Prefix expression needs to be reversed
    return ans1;
}

int fun1(int n1, int n2, char c)
{
    if (c == '+')
        return n1 + n2;
    else if (c == '-')
        return n1 - n2;
    else if (c == '*')
        return n1 * n2;
    else if (c == '/')
        return n1 / n2;
    else if (c == '%')
        return n1 % n2;
    return 0;
}

int infixpost()
{
    cout << "Enter postfix expression: ";
    string b = "12+34+*";
    stack<int> num;

    for (int i = 0; i < b.length(); i++)
    {
        if (isop(b[i]))
        {
            int a2 = num.top();
            num.pop();
            int a1 = num.top();
            num.pop();
            int a3 = fun1(a1, a2, b[i]);
            num.push(a3);
        }
        else
        {
            int y = (b[i] - '0');
            num.push(y);
        }
    }
    return num.top();
}

int evaluatePrefix()
{
    stack<int> st;
    string b;
    cin >> b;
    for (int i = b.length() - 1; i >= 0; i--)
    {
        if (isop(b[i]))
        {
            int a1 = st.top();
            st.pop();
            int a2 = st.top();
            st.pop();
            int a3 = fun1(a2, a1, b[i]);
            st.push(a3);
        }
        else st.push(b[i]-'0');
    }
    return st.top();
}

int main()
{
    string s;
    cin >> s;
    int n = s.size();

    stack<char> st;
    string ans = postfix(st, s, "", n);
    cout << "Postfix: " << ans << endl;

    string ans1 = "";
    reverse(s.begin(), s.end());
    stack<char> st1;
    ans1 = prefix(st1, ans1, s);
    cout << "Prefix: " << ans1 << endl;

    int ans3 = infixpost();
    cout << "Postfix evaluation result: " << ans3 << endl;

    int ans4 = evaluatePrefix();
    cout << "Prefix evaluation result: " << ans4 << endl;
    return 0;
}