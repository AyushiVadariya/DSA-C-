#include<iostream>
using namespace std;
class node
{
    public:

    int data;
    node *link;

    node(int d)
    {
        data=d;
        link=nullptr;
    }
};
class implementation
{
    node *first;
    public:

    implementation()
    {
        first=nullptr;
    }
    void insertend(int d)
    {
        node *nn=new node(d);
        {
            if(first==nullptr)
            {
                first=nn;
            }
            else{
                node *temp=first;
                while(temp->link!=nullptr)
                {
                    temp=temp->link;
                }
                temp->link=nn;
            }
        }
    }
    void  displayrecursion(node *t)
    {
       if(t!=nullptr)
        {
            cout<<t->data<<endl;
           displayrecursion(t->link);
        }

    }
    void display()
    {
         displayrecursion(first);
    }
};
int main()
{
    implementation obj1;
    obj1.insertend(10);
    obj1.insertend(20);
    obj1.insertend(30);
    obj1.insertend(40);
    obj1.insertend(50);
    obj1.display();
}