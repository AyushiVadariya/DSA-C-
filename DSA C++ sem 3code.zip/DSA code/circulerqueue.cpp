#include <iostream>
using namespace std;
const int size = 5;
class queue
{
    int front;
    int rear;
    int q[size];

public:
    queue()
    {
        front = -1;
        rear = -1;
    }
    void Enqueue(int n)
    {
        if (front == (rear + 1) % size)
        {
            cout << "queue is full" << endl;
            return;
        }
        else if (front == -1)
        {
            front = rear = 0;
        }
        else
        {
            rear = (rear + 1) % size;
        }
        q[rear] = n;
    }
    void dequeue()
    {
        int n = q[front];
        if (front == -1)
        {
            cout << "queue is empty " << endl;
        }
        else if (front == rear)
        {
            front = rear = -1;
        }
        else
        {
            front = (front + 1) % size;
        }
        cout << n << endl;
    }
};
int main()
{
    queue q1;
    for (int i = 1; i <=5; i++)
    {
        q1.Enqueue(i);
    }
    for (int i = 0; i < size; i++)
    {
        q1.dequeue();
    }
    for (int i = 6; i <=10; i++)
    {
        q1.Enqueue(i);
    }
    for (int i = 0; i < 5; i++)
    {
        q1.dequeue();
    }
}