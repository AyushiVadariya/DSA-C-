#include<iostream>
#include<stack>
#include<string.h>
using namespace std;
int precedence(char c) {
    if(c == '^')
        return 3;
    else if(c == '*' || c == '/')
        return 2;
    else if(c == '+' || c == '-')
        return 1;
    else
        return -1;
}
int main()
{
    string s;
    cout << "Enter expression";
    cin >> s;
    stack<char>s1;
    bool balanced = true;
    for(int i=0;i<s.length();i++)
    {
        if(isalnum(s[i])==1)
        {
            cout<<s[i];
        }
        else if(s[i]=='(')
        {
            s1.push(s[i]);
        }
        else if(s[i]==')')
        {
            if (s1.empty()) {
                cout << "Error: Unbalanced parentheses" << endl;
                balanced = false;
                break;
            }
           while(s1.top()!='(' && !s1.empty())
           {
                cout<<s1.top();
                s1.pop();
                //((A*(B+D)/E)-F*(G+H/K))
           }
           s1.pop();
        }
         else if (s[i] == '+' || s[i] == '-' || s[i]== '*' || s[i] == '/' || s[i] == '^')  {
            while(!s1.empty() && precedence(s[i]) <= precedence(s1.top())) {
                cout<<s1.top();
                s1.pop();
            }
            s1.push(s[i]);
        }
        else {
            cout << "Error: Invalid character '" << s[i] << "' in expression" << endl;
            return false;
        }
        while (!s1.empty()) {
        if (s1.top() == '(') {
            cout << "Error: Unbalanced parentheses" << endl;
            balanced = false;
            break;
        }
        cout << s1.top();
        s1.pop();
    }

    if (balanced) {
        cout << endl;  // Print the final postfix expression if parentheses are balanced
    }
    }

}