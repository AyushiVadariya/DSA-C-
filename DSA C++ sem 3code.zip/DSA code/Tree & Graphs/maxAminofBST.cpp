#include <iostream>
#include <queue>
using namespace std;
class tree;
class node
{
    int data;
    node *left;
    node *right;

public:
    node(int d)
    {
        data = d;
        left = right = NULL;
    }
    friend class tree;
};
class tree
{
public:
    node *root;
    tree()
    {
        root = NULL;
    }
   void insert(node *root,node *n)
    {
        if (n->data > root->data)
        {
            if (root->right == NULL)
                root->right = n;
            else
                insert(root->right, n);
        }

        if (n->data < root->data)
        {
            if (root->left == NULL)
                root->left = n;
            else
                insert(root->left, n);
        }
    }
    int findmin(node *root)
    {
        node *temp=root;
        while(temp->left->left!=NULL)
        {
            temp=temp->left;
        }
        cout<<temp->data;
    }
    int findmax(node *root)
    {
        node *temp=root;
        while(temp->right->right!=NULL)
        {
            temp=temp->right;
        }
        cout<<temp->data;
    }
    void addnode(int d)
    {
        if (root == NULL)
        {
            node *nn = new node(d);
            root = nn;
        }
        else
        {
            node *nn = new node(d);
            insert(root, nn);
        }
    }
    int fmin()
    {
        findmin(root);
    }
    int fmax()
    {
        findmax(root);
    }
};
int main()
{
    tree t1;
    t1.addnode(1);
    t1.addnode(2);
    t1.addnode(3);
    t1.addnode(4);
    t1.addnode(5);
    t1.addnode(6);
    t1.fmin();
    t1.fmax();
}