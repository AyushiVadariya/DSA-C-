#include<iostream>
using namespace std;
int heapsort(int a[],int n,int k)
{
    for(int i=1;i<=n;i++)
    {
        if(i==1)
        {
            break;
        }
        else if(k<=a[i/2]);
        {
            break;
        }
        a[i]=k;
        else
        {
            a[i]=a[i/2];
            i=i/2;
        }
        a[i]=k;
    }
}
int main()
{
    int n,i,k;
    cout<<"enter the size of array";
    cin>>n;
    int a[n];
    for(int i=1;i<=n;i++)
    {
        cin>>a[i];
    }
    for(int i=1;i<=n;i++)
    {
        k=a[i];
        heapsort(a,n,k);
    }
    for(int i=1;i<=n;i++)
    {
        cout<<a[i];
    }
}
