#include <iostream>
#include <queue>
using namespace std;
class tree;
class node
{
    int data;
    node *left;
    node *right;

public:
    node(int d)
    {
        data = d;
        left = right = NULL;
    }
    friend class tree;
};
class tree
{
public:
    node *root;
    tree()
    {
        root = NULL;
    }
    void insert(node *root, node *n)
    {
        char ch;
        cout << "enter choice for" << n->data << endl;
        cin >> ch;
        if (ch == 'r')
        {
            if (root->right == NULL)
            {
                root->right = n;
            }
            else
            {
                cout << root->data << "not null eneter choice for this node" << endl;
                insert(root->right, n);
            }
        }
        else
        {
            if (root->left == NULL)
                root->left = n;
            else
            {
                cout << root->data << "not null enetr choice for this node" << endl;
                insert(root->left, n);
            }
        }
    }
    void levelorder(node *root)
    {
        if (root == NULL)
            return;
        queue<node *> Q;
        Q.push(root);
        while (!Q.empty())
        {
            node *current = Q.front();
            cout << current->data;
             Q.pop();
            if (current->left != NULL)
                Q.push(current->left);
            if (current->right != NULL)
                Q.push(current->right);
            // Q.pop();
        }
    }
    int sym(node *root)
    {
        if(root!=nullptr)
        return true;
        if(root->right && root->left)
        {
            if((root->right->right && root->left->right) || (root->left->left && root->right->left))
            {
                sym(root->left);
                ;sym(root->right);
                return true;
            }
            
        }
        else{
            return false;
        }
    }
    void addnode(int d)
    {
        if (root == NULL)
        {
            node *nn = new node(d);
            root = nn;
        }
        else
        {
            node *nn = new node(d);
            insert(root, nn);
        }
    }
        void display()
    {
        levelorder(root);
        if(sym(root)==true)
        {
            cout<<"true";
        }
        else{
            cout<<"false";
        }
    }
};
int main()
{
    tree t1;
    t1.addnode(1);
    t1.addnode(2);
    t1.addnode(3);
    t1.addnode(4);
    t1.addnode(5);
    t1.addnode(6);
     t1.addnode(7);
    t1.display();
}