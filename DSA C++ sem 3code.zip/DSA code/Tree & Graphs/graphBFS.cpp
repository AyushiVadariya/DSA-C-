#include <iostream>
#include <queue>
using namespace std;
void trav(int v1, int a[5][5])
{
    queue<int> q;
    static bool visited[5];
    visited[v1] = true;
    q.push(v1);
    while (!q.empty())
    {
        v1 = q.front();
        q.pop();
        cout << v1 << endl;
        for (int v2 = 0; v2 < 5; v2++)
        {
            if (a[v1][v2] == 1 && visited[v2] == false)
            {
                q.push(v2);
                visited[v2] = true;
            }
        }
    }
}
int main()
{
    int a[5][5] = {0};
    int x = 1;
    int v1, v2;
    while (x == 1)
    {
        cout << "enter 2 nodes which are join";
        cin >> v1 >> v2;
        a[v1][v2] = 1;
        a[v2][v1] = 1;
        cout << "enetr 1 for more nodes addition";
        cin >> x;
    }
    trav(v1, a);
    return 0;
}
// output:0 1 2 3 4