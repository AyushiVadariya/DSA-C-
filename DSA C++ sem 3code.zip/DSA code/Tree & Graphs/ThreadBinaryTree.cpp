#include <iostream>
using namespace std;
class node
{
public:
    int data;
    node *left;
    node *right;
    bool rightthread;
    bool leftthread;

    node *addnode()
    {
        node *temp;
        temp = new node();
        temp->right = nullptr;
        temp->left = nullptr;
        temp->rightthread = true;
        temp->rightthread = true;
        return temp;
    }
    void insert(node *root, node *n)
    {
        if (n->data > root->data)
        {
            if (root->right == nullptr)
            {
                root->right = n;
                root->rightthread = false;
            }
            else
            {
                insert(root->right, n);
            }
        }
        else
        {
            if (root->left == nullptr)
            {
                root->left = n;
                root->leftthread = false;
            }
            else
            {
                insert(root->left, n);
            }
        }
    }
    int inordersucc(node *root, int x)
    {
        node *currentnode = root;
        while (currentnode->data != x)
        {
            if (x > currentnode->data)
            {
                currentnode = currentnode->right;
            }
            else
            {
                currentnode = currentnode->left;
            }
        }
        node *temp = currentnode->right;
        if (!currentnode->rightthread)
        {
            while(!temp->leftthread)
            {
                temp = temp->left;
            }
             currentnode = temp;
            if (currentnode == root)
                return 0;
            else
                return currentnode->data;
        }
    }
    int main()
    {
        node *New, *root;
        root = NULL;
        char ans;
        do
        {
            New = addnode();
            cout << "enetr data";
            cin >> New->data;
            if (root == NULL)
                root = New;
            else
                insert(root, New);
            cout << "do you want to enter more elements ";
            char ans = getchar();
        } while (ans == 'y');
        return 0;
    }
};
        