#include<iostream>
using namespace std;
void trav(int v1,int a[5][5])
{
    static bool visited[5];
    cout<<v1;
    visited[v1]=true;
    for(int v2=0;v2<5;v2++)
    {
        if(a[v1][v2]==1 && visited[v2]==false)
        {
            trav(v2,a);
        }
    }
}
int main()
{
    int a[5][5]={0};
    int x=1;
    int v1,v2;
    while(x==1)
    {
        cout<<"enter 2 nodes which are join";
        cin>>v1>>v2;
        a[v1][v2]=1;
        a[v2][v1]=1;
        cout<<"enetr 1 for more nodes addition";
        cin>>x;   
    }
     trav(v1,a);
        return 0;
}
//output : 01324