#include <iostream>
using namespace std;

class BST
{
public:
    int data;
    BST *left;
    BST *right;

    BST()
    {
        left = right = NULL;
    }
};

class work
{
public:
    BST *root;
    int count = 0;

    work()
    {
        root = NULL;
    }

    void Make()
    {
        int d;
        do
        {
            BST *nn = new BST();
            cout << "Enter data: ";
            cin >> nn->data;

            if (root == NULL)
            {
                root = nn;
            }
            else
            {
                Insert(root, nn);
            }

            cout << "Enter 1 to insert more nodes: ";
            cin >> d;
        } while (d == 1);
    }

    void Insert(BST *r, BST *nn)
    {
        if (nn->data > r->data)
        {
            if (r->right == NULL)
                r->right = nn;
            else
                Insert(r->right, nn);
        }

        if (nn->data < r->data)
        {
            if (r->left == NULL)
                r->left = nn;
            else
                Insert(r->left, nn);
        }
    }

    BST *Search(BST *r, int k)
    {
        BST *temp = r;

        while (temp != NULL)
        {
            if (temp->data == k)
            {
                cout << "Element is present!" << endl;
                return temp;
                break;
            }
            else{
                if (k < temp->data)
                temp = temp->left;

            if (k > temp->data)
                temp = temp->right;
            }

            
        }

        if (temp == NULL)
            cout << "Element is not present!" << endl;

        return temp;
    }

    void asc(BST *r)
    {
        if (r == NULL)
            return;
        asc(r->left);
        cout << r->data << "\t";
        asc(r->right);
    }

    void dsc(BST *r)
    {
        if (r == NULL)
            return;
        dsc(r->right);
        cout << r->data << "\t";
        dsc(r->left);
    }

    void k_high(BST *r, int k)
    {
        if (r != NULL && count <= k)
        {
            k_high(r->right, k);
            count++;
            if (count == k)
                cout << r->data << endl;
            k_high(r->left, k);
        }
    }

    void k_low(BST *r, int k)
    {
        if (r != NULL && count <= k)
        {
            k_low(r->left, k);
            count++;
            if (count == k)
                cout << r->data << endl;
            k_low(r->right, k);
        }
    }
};

int main()
{
    int k;

    work T;
    T.Make();

    cout << "\nEnter element to search: ";
    cin >> k;
    T.Search(T.root, k);

    cout << endl;
    T.asc(T.root);
    cout << endl
         << endl;

    T.dsc(T.root);
    cout << endl
         << endl;

    T.k_high(T.root, 2);
    T.k_low(T.root, 2);
    return 0;
}