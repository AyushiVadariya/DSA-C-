#include<iostream>
using namespace std;
struct node
{
    public:

    int data;
    struct node *link;

    node(int d)
    {
        data=d;
        link='\0';
    }
};
class implementation
{
    node *first;
    public:

    implementation()
    {
        first='\0';
    }
    void insertend(int d)
    {
        node *nn=new node(d);
        {
            if(first=='\0')
            {
                first=nn;
            }
            else{
                node *temp=first;
                while(temp->link!='\0')
                {
                    temp=temp->link;
                }
                temp->link=nn;
            }
        }
    }
    void solve(node *start)
    {
        if(start==nullptr)
        {
            return;
        }
        cout<<start->data;
        if(start->link!=nullptr)
        {
            solve(start->link->link);
            cout<<start->data;
        }
    }
    void display()
    {
        // node *temp=first;
        // while(temp!='\0')
        // {
        //     cout<<temp->data<<endl;
        //     temp=temp->link;
        //      //cout<<temp->data<<endl;
        // }
        solve(first);
    }
};
int main()
{
    implementation obj1;
    obj1.insertend(1);
    obj1.insertend(2);
    obj1.insertend(3);
    obj1.insertend(4);
    obj1.insertend(5);
    obj1.insertend(6);
    obj1.display();
}
// int pop() {

// if (s.empty())

// { std::cout << "stack is empty"; return -1; }

// int x = s.top();
// s.pop();
// if (s.empty()) {return x};

// int item = pop();
// s.push();
// return item;
// }