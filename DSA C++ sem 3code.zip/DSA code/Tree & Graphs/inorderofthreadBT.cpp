#include <iostream>
using namespace std;
class tree;
class node
{
    int data;
    node *left;
    node *right;
    bool *leftthread;
    bool *rightthread;

public:
    node(int d)
    {
        data = d;
        left = right = NULL;
    }
    friend class tree;
};
class tree
{
public:
    node *root;
    tree()
    {
        root = NULL;
    }
    void insert(node *root, node *n)
    {
        char ch;
        cout << "enter choice for" << n->data << endl;
        cin >> ch;
        if (ch == 'r')
        {
            if (root->right == NULL)
            {
                root->right = n;
            }
            else
            {
                cout << root->data << "not null eneter choice for this node" << endl;
                insert(root->right, n);
            }
        }
        else
        {
            if (root->left == NULL)
                root->left = n;
            else
            {
                cout << root->data << "not null enetr choice for this node" << endl;
                insert(root->left, n);
            }
        }
    }
    // int inordersucc(node *currentnode)
    // {
    //     node *temp = currentnode->right;
    //     if (currentnode->rightthread)
    //     {
    //         while (!temp->leftthread)
    //         {
    //             currentnode = temp;
    //             temp = temp->left;
    //         }
    //        if (currentnode == root)
    //         {
    //             return 0;
    //         }
    //         else
    //         {
    //             return currentnode->data;
    //          }
    //     }
         
    // }
    int inOrderSuccessor(node *root, node *x)
    {
       
       Node *temp=root;
       if(temp->right)
       {
           temp=temp->right;
           if(temp->right->left)
           {
               temp=temp->right->left;
               return temp;
           }
           else
           {
               temp=temp->right;
               return temp;
           }
       }
       else
       {
           return temp;
       }
        
    }
    void addnode(int d)
    {
        if (root == NULL)
        {
            node *nn = new node(d);
            root = nn;
        }
        else
        {
            node *nn = new node(d);
            insert(root, nn);
        }
    }
    void display()
    {
        cout<<inordersucc(root,);
    }
};
int main()
{
    tree t1;
    t1.addnode(6);
    t1.addnode(2);
    t1.addnode(7);
    // t1.addnode(1);
    // t1.addnode(4);
    // t1.addnode(9);
    // t1.addnode(3);
    // t1.addnode(5);
    // t1.addnode(8);
    t1.inOrder();
    t1.display();
}