#include <iostream>
#include <stack>
using namespace std;
class node
{
    int data;
    node *link;
    friend class imp;
    public:
    node(int d)
    {
        data=d;
        link=NULL;
    }
};
class imp
{
    node *first;
    public:
    imp()
    {
        first=NULL;
    }
    void addnode(int d)
    {
        node *nn=new node(d);
    if(first==NULL)
    {
        first=nn;
    }
    else
    {
        node *temp=first;
        while(temp->link!=NULL)
        temp=temp->link;
        temp->link=nn;
    }
    }
    void display()
    {
        node *temp=first;
        while(temp!=NULL)
        {
            cout<<temp->data<<endl;
            temp=temp->link;
        }
    }
    int add(node *secondp)
    {
       node *first=this->first;
        node *second=secondp;
        node *temp=first;
        int x;
        while(temp->link!=NULL)
        {
            x=temp->link->data=temp->data*10+temp->link->data;
            temp=temp->link;
        }
        cout<<"X = "<<x<<endl;
        node *temp1=second;
        int y;
        while(temp1->link!=NULL)
        {
            y=temp1->link->data=temp1->data*10+temp1->link->data;
            temp1=temp1->link;
        }
         cout<<"Y = "<<y<<endl;
        int z;
        z=x+y;
        cout<<"Sum of two link : "<<z<<endl;
        return z;
    }
    node* address(){return first;}
};
int main()
{
    imp i;
    i.addnode(5);
    i.addnode(6);
    i.addnode(3);
    cout<<"First link list :"<<endl;
    i.display();
    imp i1;
    i1.addnode(8);
    i1.addnode(4);
    i1.addnode(2);
    cout<<"Second link list :"<<endl;
    i1.display();
    int z=i.add(i1.address());
    cout<<"Final link list : "<<endl;
    stack<int> s1;
    int d,count=0;
    int j=0;
    while(z>0)
    {
        d=z%10;
        s1.push(d);
        
        z=z/10;
        count++;
    }
    
    imp i2;
    while(j<count)
    {
        i2.addnode(s1.top());
        s1.pop();
        j++;
    }
    i2.display();
}